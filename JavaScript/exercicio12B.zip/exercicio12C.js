var termo = prompt("Digite o primeiro termo ?");
var razao = prompt("Digite a razão que deseja saber ??");

function procuraTermoPa(termo, razao)
{
    if()
    {
    var an = termo+(termo-1)*razao;
    }
}